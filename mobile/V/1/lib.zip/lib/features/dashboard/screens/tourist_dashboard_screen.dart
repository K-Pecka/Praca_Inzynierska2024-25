import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../budget/screens/tourist_budget_screen.dart';
import '/core/models/trip_model.dart';
import '../widgets/dashboard_widgets.dart';
import '/core/widgets/bottom_navigation.dart';
import 'package:intl/intl.dart';

class TouristDashboard extends StatefulWidget {
  final String token;
  final int userProfileId;

  const TouristDashboard({
    super.key,
    required this.token,
    required this.userProfileId,
  });

  @override
  State<TouristDashboard> createState() => _TouristDashboardState();
}

class _TouristDashboardState extends State<TouristDashboard> {
  List<TripModel> _trips = [];
  TripModel? _selectedTrip;
  bool _isLoading = true;
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _fetchTrips();
  }

  Future<void> _fetchTrips() async {
    final response = await http.get(
      Uri.parse('https://api.plannder.com/trip/all/'),
      headers: {
        'accept': 'application/json',
        'Authorization': 'Bearer ${widget.token}',
      },
    );

    if (response.statusCode == 200) {
      final List<dynamic> data = jsonDecode(response.body);
      setState(() {
        _trips = data.map((e) => TripModel.fromJson(e)).toList();
        _selectedTrip = _trips.isNotEmpty ? _trips.first : null;
        _isLoading = false;
      });
    } else {
      setState(() => _isLoading = false);
    }
  }

  int _calculateTripDuration(DateTime start, DateTime end) =>
      end.difference(start).inDays + 1;

  void _onNavBarTap(int index) {
    if (index == 2 && _selectedTrip != null) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => TouristBudgetScreen(
            token: widget.token,
            tripId: _selectedTrip!.id,
            userProfileId: widget.userProfileId,
          ),
        ),
      );
    } else {
      setState(() => _currentIndex = index);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 32),
              const Text(
                'Witaj! Mateusz',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w600,
                  color: Colors.black87,
                ),
              ),
              const SizedBox(height: 24),
              if (_selectedTrip != null)
                TripDropdownCard(
                  trips: _trips,
                  selectedTrip: _selectedTrip!,
                  onTripSelected: (trip) =>
                      setState(() => _selectedTrip = trip),
                ),
              const SizedBox(height: 16),
              if (_selectedTrip != null)
                TripDetailsCard(
                  trip: _selectedTrip!,
                  duration: _calculateTripDuration(
                    _selectedTrip!.startDate,
                    _selectedTrip!.endDate,
                  ),
                ),
              const Spacer(),
            ],
          ),
        ),
      ),
      bottomNavigationBar: CustomBottomNavBar(
        currentIndex: _currentIndex,
        onTap: _onNavBarTap,
      ),
    );
  }
}