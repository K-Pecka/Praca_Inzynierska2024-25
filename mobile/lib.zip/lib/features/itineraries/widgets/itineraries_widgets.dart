import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '/core/models/itinerary_model.dart';
import '/core/theme/text_styles.dart';
import '/core/theme/icons.dart';

class DaySelector extends StatefulWidget {
  final DateTime start;
  final DateTime end;
  final List<ItineraryModel> activeDays;
  final DateTime selected;
  final ValueChanged<DateTime> onSelect;

  const DaySelector({
    super.key,
    required this.start,
    required this.end,
    required this.activeDays,
    required this.selected,
    required this.onSelect,
  });

  @override
  State<DaySelector> createState() => _DaySelectorState();
}

class _DaySelectorState extends State<DaySelector> {
  final _scrollController = ScrollController();

  List<DateTime> _generateDays() {
    final days = <DateTime>[];
    for (DateTime d = widget.start; !d.isAfter(widget.end); d = d.add(const Duration(days: 1))) {
      days.add(d);
    }
    return days;
  }

  @override
  void didUpdateWidget(covariant DaySelector oldWidget) {
    super.didUpdateWidget(oldWidget);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final days = _generateDays();
      final selectedIndex = days.indexWhere((d) =>
      d.year == widget.selected.year &&
          d.month == widget.selected.month &&
          d.day == widget.selected.day);

      if (selectedIndex != -1) {
        final offset = (selectedIndex - 2).clamp(0, days.length) * 64.0; // 56 width + 8 spacing
        _scrollController.animateTo(
          offset,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final days = _generateDays();

    return SizedBox(
      height: 64,
      child: ListView.separated(
        controller: _scrollController,
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        itemCount: days.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final date = days[index];
          final isActive = widget.activeDays.any((it) =>
          !date.isBefore(it.startDate) && !date.isAfter(it.endDate));
          final isSelected = date.day == widget.selected.day && date.month == widget.selected.month;

          return GestureDetector(
            onTap: () => widget.onSelect(date),
            child: Container(
              width: 56,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: isSelected
                    ? const Color(0xFF6C55ED)
                    : isActive
                    ? const Color(0x80DEDCFF)
                    : const Color(0x1A000000),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                DateFormat('d').format(date),
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: isSelected ? Colors.white : Colors.black87,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class MockActivitiesList extends StatelessWidget {
  const MockActivitiesList({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(8),
      itemCount: 3,
      itemBuilder: (context, index) {
        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFFF4F2FF),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                children: [
                  Icon(Icons.restaurant, color: Colors.black87),
                  SizedBox(width: 8),
                  Text('Tytuł', style: TextStyle(fontWeight: FontWeight.w600)),
                ],
              ),
              const SizedBox(height: 8),
              const Row(
                children: [
                  Icon(Icons.access_time, size: 16, color: Colors.black54),
                  SizedBox(width: 4),
                  Text('12:00:00', style: TextStyle(color: Colors.black54)),
                  SizedBox(width: 12),
                  Icon(Icons.access_time_filled, size: 16, color: Colors.black54),
                  SizedBox(width: 4),
                  Text('1h 30m', style: TextStyle(color: Colors.black54)),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

class PlanDropdownCard extends StatelessWidget {
  final List<ItineraryModel> plans;
  final ItineraryModel selectedPlan;
  final ValueChanged<ItineraryModel> onPlanSelected;

  const PlanDropdownCard({
    super.key,
    required this.plans,
    required this.selectedPlan,
    required this.onPlanSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0x80DEDCFF),
        borderRadius: BorderRadius.circular(24),
      ),
      padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          ColorFiltered(
            colorFilter: const ColorFilter.mode(Color(0xB32F27CE), BlendMode.srcIn),
            child: SizedBox(width: 32, height: 32, child: AppIcons.map),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: DropdownButtonHideUnderline(
              child: DropdownButton<ItineraryModel>(
                isExpanded: true,
                value: selectedPlan,
                icon: const Icon(Icons.keyboard_arrow_down_rounded, color: Colors.black54),
                dropdownColor: Colors.white,
                borderRadius: BorderRadius.circular(16),
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  color: Colors.black87,
                ),
                itemHeight: 48,
                elevation: 3,
                selectedItemBuilder: (context) => plans.map((plan) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text('Obecny plan', style: TextStyles.cardTitleHeading),
                      Text(
                        plan.name,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Colors.black87,
                          fontFamily: 'Quicksand',
                        ),
                      ),
                    ],
                  );
                }).toList(),
                items: plans.map((plan) {
                  return DropdownMenuItem(
                    value: plan,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: Text(
                        plan.name,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w500,
                          color: Colors.black87,
                        ),
                      ),
                    ),
                  );
                }).toList(),
                onChanged: (ItineraryModel? newPlan) {
                  if (newPlan != null) onPlanSelected(newPlan);
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}


